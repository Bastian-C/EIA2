var Aufgabe12;
(function (Aufgabe12) {
    class moving {
        constructor() {
            this.alife = true;
        }
        draw() {
        }
        update() {
            this.move();
            this.draw();
        }
        move() {
        }
    }
    Aufgabe12.moving = moving;
})(Aufgabe12 || (Aufgabe12 = {}));
//# sourceMappingURL=moving.js.map