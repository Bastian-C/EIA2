interface Leaderboard {
    [key: string]: string;
}

interface PlayerScore {
    playerName: string;
    score: number;
}
 